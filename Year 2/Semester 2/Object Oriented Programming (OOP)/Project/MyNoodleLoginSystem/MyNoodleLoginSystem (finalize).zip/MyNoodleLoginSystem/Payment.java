public class Payment implements Payable {
    private String method;
    private double amount;

    public Payment(String method, double amount) {
        this.method = method;
        this.amount = amount;
    }

    @Override
    public void processPayment() {
        System.out.println("Payment of RM" + amount + " using " + method + " is processed.");
    }
}