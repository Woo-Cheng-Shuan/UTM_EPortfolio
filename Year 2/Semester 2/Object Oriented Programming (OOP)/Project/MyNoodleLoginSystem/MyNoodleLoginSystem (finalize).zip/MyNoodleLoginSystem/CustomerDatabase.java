import java.io.*;
import java.util.*;

public class CustomerDatabase {
    private static final String FILE_NAME = "customers.txt";

    public static boolean registerCustomer(Customer customer) {
        if (isUsernameTaken(customer.getUsername())) return false;
        try (PrintWriter writer = new PrintWriter(new FileWriter(FILE_NAME, true))) {
            writer.println(customer.getUsername() + "," + customer.getPassword() + "," + customer.getName() + "," +
                    customer.getPhone() + "," + customer.getAddress() + "," + customer.getEmail());
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public static Customer login(String username, String password) {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 6 && data[0].equals(username) && data[1].equals(password)) {
                    return new Customer("C001", data[0], data[1], data[2], data[3], data[4], data[5]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private static boolean isUsernameTaken(String username) {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 1 && data[0].equals(username)) return true;
            }
        } catch (IOException e) {
            // File might not exist yet, which is okay
        }
        return false;
    }
}