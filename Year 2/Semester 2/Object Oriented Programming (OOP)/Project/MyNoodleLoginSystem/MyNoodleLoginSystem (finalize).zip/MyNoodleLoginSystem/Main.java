import javax.swing.*;

public class Main {

    private static String generateOrderId() {
        int nextCounter = getNextOrderCounter();
        return String.format("%03d", nextCounter);
    }

    private static int getNextOrderCounter() {
        int maxCounter = 0;
        try {
            java.nio.file.Path salesLogPath = java.nio.file.Paths.get("sales_log.txt");
            if (java.nio.file.Files.exists(salesLogPath)) {
                java.util.List<String> lines = java.nio.file.Files.readAllLines(salesLogPath);
                for (String line : lines) {
                    String[] parts = line.split("\\|");
                    if (parts.length >= 2) {
                        String orderId = parts[1].trim();
                        try {
                            // Try to parse the order ID as a simple number
                            int counter = Integer.parseInt(orderId);
                            if (counter > maxCounter) {
                                maxCounter = counter;
                            }
                        } catch (NumberFormatException e) {
                            // Skip invalid counter formats
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Error reading sales log: " + e.getMessage());
        }
        return maxCounter + 1;
    }

    public static void main(String[] args) {
        Customer customer = null;
        while (customer == null) {
            int choice = JOptionPane.showOptionDialog(null, "Welcome to MyNoodle System", "Main Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, 
                    new String[]{"Customer", "Exit"}, "Customer");

            if (choice == 0) {
                customer = handleLogin();
            } else {
                System.exit(0);
            }
        }
        runOrderingFlow(customer, null);
    }

    private static Customer handleLogin() {
        int choice = JOptionPane.showOptionDialog(null, "Customer Menu", "Login/Register",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, 
                new String[]{"Login", "Register", "Back"}, "Login");

        if (choice == 0) {
            return loginCustomer();
        } else if (choice == 1) {
            registerCustomer();
        }
        return null;
    }

    private static String getValidatedInput(String prompt, String fieldName, java.util.function.Consumer<String> validator) {
        while (true) {
            String input = JOptionPane.showInputDialog(prompt);
            if (input == null) return null; // User cancelled
            try {
                validator.accept(input);
                return input;
            } catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "Invalid " + fieldName, JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void registerCustomer() {
        try {
            String username = getValidatedInput("Choose username:", "Username", ValidationUtils::validateUsername);
            if (username == null) return;
            
            String password = getValidatedInput("Choose password:", "Password", ValidationUtils::validatePassword);
            if (password == null) return;
            
            String name = getValidatedInput("Enter name:", "Name", ValidationUtils::validateName);
            if (name == null) return;
            
            String phone = getValidatedInput("Enter phone number:", "Phone Number", ValidationUtils::validatePhone);
            if (phone == null) return;
            
            String address = getValidatedInput("Enter address:", "Address", ValidationUtils::validateAddress);
            if (address == null) return;
            
            String email = getValidatedInput("Enter email:", "Email", ValidationUtils::validateEmail);
            if (email == null) return;

            Customer newCustomer = new Customer("C001", username, password, name, phone, address, email);
            if (CustomerDatabase.registerCustomer(newCustomer)) {
                JOptionPane.showMessageDialog(null, "Registration successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Username already taken!", "Registration Failed", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Unexpected error during registration: " + e.getMessage(), 
                "Registration Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static Customer loginCustomer() {
        try {
            String username = JOptionPane.showInputDialog("Enter username:");
            String password = JOptionPane.showInputDialog("Enter password:");
            Customer customer = CustomerDatabase.login(username, password);
            if (customer != null) {
                JOptionPane.showMessageDialog(null, "Welcome, " + customer.getName() + "!");
                return customer;
            } else {
                JOptionPane.showMessageDialog(null, "Login failed. Invalid credentials.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Login error: " + e.getMessage());
        }
        return null;
    }

    private static void runOrderingFlow(Customer customer, Order order) {
        MenuItem[] menuItems = {
            new MenuItem("M001", "Beef Noodle", "Spicy beef soup", 12.50, true),
            new MenuItem("M002", "Veggie Noodle", "Vegetarian", 10.00, true),
            new MenuItem("M003", "Chicken Noodle", "Chicken soup", 11.50, true),
            new MenuItem("M004", "Cold Noodle", "Cold noodle dish", 12.50, true),
            new MenuItem("M005", "Spicy Noodle", "Extra spicy soup", 12.50, true)
        };

        String[] options = java.util.Arrays.stream(menuItems)
            .map(item -> item.getName() + " - RM" + item.getPrice())
            .toArray(String[]::new);

        int choice = JOptionPane.showOptionDialog(null, "Choose a menu item", "Menu",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        if (choice == JOptionPane.CLOSED_OPTION || choice < 0 || choice >= menuItems.length) return;

        try {
            int quantity = Integer.parseInt(JOptionPane.showInputDialog("Enter quantity:"));
            if (order == null) {
                order = new Order(generateOrderId(), customer);
            }
            order.addItem(new OrderItem(menuItems[choice], quantity));
            order.saveReceiptOnly();
            showOrderTrackingScreen(order, customer);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a valid number for quantity.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void showOrderTrackingScreen(Order order, Customer customer) {
        java.util.List<OrderItem> items = order.getItems();
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        
        JCheckBox[] checkBoxes = items.stream()
            .map(item -> new JCheckBox(item.getMenuItem().getName() + " x" + item.getQuantity()))
            .toArray(JCheckBox[]::new);
        
        java.util.Arrays.stream(checkBoxes).forEach(panel::add);
        
        JButton addOrderBtn = new JButton("Add Order");
        JButton doneBtn = new JButton("Done");
        doneBtn.setEnabled(false);
        
        JPanel btnPanel = new JPanel();
        btnPanel.add(addOrderBtn);
        btnPanel.add(doneBtn);
        panel.add(btnPanel);

        java.awt.event.ItemListener checkListener = e -> 
            doneBtn.setEnabled(java.util.Arrays.stream(checkBoxes).allMatch(JCheckBox::isSelected));
        
        java.util.Arrays.stream(checkBoxes).forEach(cb -> cb.addItemListener(checkListener));

        JDialog dialog = new JDialog();
        dialog.setTitle("Order Tracking");
        dialog.setModal(true);
        dialog.setContentPane(panel);
        dialog.pack();
        dialog.setLocationRelativeTo(null);

        addOrderBtn.addActionListener(e -> {
            dialog.dispose();
            runOrderingFlow(customer, order);
        });
        doneBtn.addActionListener(e -> {
            dialog.dispose();
            order.finalizeOrder();
            showReceiptDialog(order, customer);
        });

        dialog.setVisible(true);
    }

    private static void showReceiptDialog(Order order, Customer customer) {
        StringBuilder sb = new StringBuilder();
        sb.append("Customer: ").append(customer.getName()).append("\n");
        
        order.getItems().forEach(item -> 
            sb.append(item.getMenuItem().getName())
              .append(" x").append(item.getQuantity())
              .append(" = RM").append(item.getSubtotal()).append("\n"));
        
        sb.append("Total: RM").append(order.getTotalAmount());
        JOptionPane.showMessageDialog(null, sb.toString(), "Receipt", JOptionPane.INFORMATION_MESSAGE);
        main(null);
    }
}