import java.io.*;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class Order {
    private String orderId;
    private Customer customer;
    private List<OrderItem> items = new ArrayList<>();
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    private static final SimpleDateFormat DATETIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public Order(String orderId, Customer customer) {
        this.orderId = orderId;
        this.customer = customer;
    }

    public void addItem(OrderItem item) {
        items.add(item);
    }

    public double getTotalAmount() {
        return items.stream().mapToDouble(OrderItem::getSubtotal).sum();
    }

    // Method to save receipt only (without logging sales)
    public void saveReceiptOnly() {
        saveReceipt();
    }

    // Method to finalize order and log sales
    public void finalizeOrder() {
        saveReceipt();
        logSales();
        updateDailyReport();
    }

    public void saveToFile() {
        saveReceipt();
        logSales();
        updateDailyReport();
    }

    private void saveReceipt() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("receipt.txt"))) {
            writer.println("=====================================");
            writer.println("            MyNoodle Receipt         ");
            writer.println("=====================================");
            writer.println("Order ID: " + orderId);
            writer.println("Date: " + DATETIME_FORMAT.format(new Date()));
            writer.println("Customer: " + customer.getName());
            writer.println("Phone: " + customer.getPhone());
            writer.println("Address: " + customer.getAddress());
            writer.println("-------------------------------------");
            writer.printf("%-20s %5s %10s\n", "Item", "Qty", "Subtotal");
            writer.println("-------------------------------------");
            for (OrderItem item : items) {
                writer.printf("%-20s %5d %10.2f\n",
                    item.getMenuItem().getName(), item.getQuantity(), item.getSubtotal());
            }
            writer.println("-------------------------------------");
            writer.printf("%-26s RM%.2f\n", "Total:", getTotalAmount());
            writer.println("=====================================");
            writer.println("Thank you for dining with us!");
        } catch (IOException e) {
            System.out.println("Error saving receipt: " + e.getMessage());
        }
    }

    private void logSales() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("sales_log.txt", true))) {
            String itemsStr = items.stream()
                .map(item -> item.getMenuItem().getName() + " x" + item.getQuantity())
                .reduce((a, b) -> a + ", " + b)
                .orElse("");
            
            writer.printf("%s | %s | %s | %.2f | %s\n",
                DATE_FORMAT.format(new Date()), orderId, customer.getName(), getTotalAmount(), itemsStr);
        } catch (IOException e) {
            System.out.println("Error logging sales: " + e.getMessage());
        }
    }

    private void updateDailyReport() {
        try {
            String today = DATE_FORMAT.format(new Date());
            String reportFile = "daily_sales_report_" + today.replace("-", "") + ".txt";
            
            Map<String, Integer> itemQtyMap = new HashMap<>();
            double totalSales = 0.0;
            int totalOrders = 0;
            
            if (Files.exists(Paths.get("sales_log.txt"))) {
                List<String> lines = Files.readAllLines(Paths.get("sales_log.txt"));
                for (String line : lines) {
                    if (line.startsWith(today)) {
                        String[] parts = line.split("\\|");
                        if (parts.length >= 5) {
                            totalSales += Double.parseDouble(parts[3].trim());
                            totalOrders++;
                            parseItems(parts[4].trim(), itemQtyMap);
                        }
                    }
                }
            }
            
            writeDailyReport(reportFile, today, totalOrders, totalSales, itemQtyMap);
        } catch (Exception e) {
            System.out.println("Error updating daily report: " + e.getMessage());
        }
    }

    private void parseItems(String itemsPart, Map<String, Integer> itemQtyMap) {
        for (String entry : itemsPart.split(", ")) {
            int xIdx = entry.lastIndexOf(" x");
            if (xIdx > 0) {
                String itemName = entry.substring(0, xIdx).trim();
                int qty = Integer.parseInt(entry.substring(xIdx + 2).trim());
                itemQtyMap.merge(itemName, qty, Integer::sum);
            }
        }
    }

    private void writeDailyReport(String reportFile, String today, int totalOrders, double totalSales, Map<String, Integer> itemQtyMap) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(reportFile))) {
            writer.println("==============================");
            writer.println("     Daily Sales Summary      ");
            writer.println("==============================");
            writer.println("Date: " + today);
            writer.println("Total Orders: " + totalOrders);
            writer.printf("Total Sales: RM%.2f\n", totalSales);
            writer.println("------------------------------");
            writer.printf("%-20s %10s\n", "Item", "Total Qty");
            writer.println("------------------------------");
            itemQtyMap.forEach((item, qty) -> writer.printf("%-20s %10d\n", item, qty));
            writer.println("==============================");
        }
    }

    public List<OrderItem> getItems() {
        return items;
    }
}