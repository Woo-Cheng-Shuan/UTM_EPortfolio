import java.util.regex.Pattern;

public class ValidationUtils {
    
    // Email validation pattern
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
        "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"
    );
    
    // Phone number validation pattern (supports various formats)
    private static final Pattern PHONE_PATTERN = Pattern.compile(
        "^[+]?[0-9]{8,15}$"
    );
    
    /**
     * Validates email address format
     * @param email the email to validate
     * @throws IllegalArgumentException if email is invalid
     */
    public static void validateEmail(String email) throws IllegalArgumentException {
        if (email == null || email.trim().isEmpty()) {
            throw new IllegalArgumentException("Email cannot be empty");
        }
        
        if (!EMAIL_PATTERN.matcher(email.trim()).matches()) {
            throw new IllegalArgumentException("Invalid email format. Please enter a valid email address.");
        }
    }
    
    /**
     * Validates phone number format
     * @param phone the phone number to validate
     * @throws IllegalArgumentException if phone number is invalid
     */
    public static void validatePhone(String phone) throws IllegalArgumentException {
        if (phone == null || phone.trim().isEmpty()) {
            throw new IllegalArgumentException("Phone number cannot be empty");
        }
        
        // Remove spaces, dashes, and parentheses for validation
        String cleanPhone = phone.replaceAll("[\\s\\-\\(\\)]", "");
        
        if (!PHONE_PATTERN.matcher(cleanPhone).matches()) {
            throw new IllegalArgumentException("Invalid phone number format. Please enter 8-15 digits.");
        }
    }
    
    /**
     * Validates address format
     * @param address the address to validate
     * @throws IllegalArgumentException if address is invalid
     */
    public static void validateAddress(String address) throws IllegalArgumentException {
        if (address == null || address.trim().isEmpty()) {
            throw new IllegalArgumentException("Address cannot be empty");
        }
        
        if (address.trim().length() < 10) {
            throw new IllegalArgumentException("Address must be at least 10 characters long");
        }
        
        if (address.trim().length() > 200) {
            throw new IllegalArgumentException("Address cannot exceed 200 characters");
        }
    }
    
    /**
     * Validates username format
     * @param username the username to validate
     * @throws IllegalArgumentException if username is invalid
     */
    public static void validateUsername(String username) throws IllegalArgumentException {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username cannot be empty");
        }
        
        if (username.trim().length() < 3) {
            throw new IllegalArgumentException("Username must be at least 3 characters long");
        }
        
        if (username.trim().length() > 20) {
            throw new IllegalArgumentException("Username cannot exceed 20 characters");
        }
        
        if (!username.matches("^[a-zA-Z0-9_]+$")) {
            throw new IllegalArgumentException("Username can only contain letters, numbers, and underscores");
        }
    }
    
    /**
     * Validates password strength
     * @param password the password to validate
     * @throws IllegalArgumentException if password is invalid
     */
    public static void validatePassword(String password) throws IllegalArgumentException {
        if (password == null || password.isEmpty()) {
            throw new IllegalArgumentException("Password cannot be empty");
        }
        
        if (password.length() < 6) {
            throw new IllegalArgumentException("Password must be at least 6 characters long");
        }
        
        if (password.length() > 50) {
            throw new IllegalArgumentException("Password cannot exceed 50 characters");
        }
    }
    
    /**
     * Validates name format
     * @param name the name to validate
     * @throws IllegalArgumentException if name is invalid
     */
    public static void validateName(String name) throws IllegalArgumentException {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name cannot be empty");
        }
        
        if (name.trim().length() < 2) {
            throw new IllegalArgumentException("Name must be at least 2 characters long");
        }
        
        if (name.trim().length() > 50) {
            throw new IllegalArgumentException("Name cannot exceed 50 characters");
        }
        
        if (!name.matches("^[a-zA-Z\\s]+$")) {
            throw new IllegalArgumentException("Name can only contain letters and spaces");
        }
    }
} 