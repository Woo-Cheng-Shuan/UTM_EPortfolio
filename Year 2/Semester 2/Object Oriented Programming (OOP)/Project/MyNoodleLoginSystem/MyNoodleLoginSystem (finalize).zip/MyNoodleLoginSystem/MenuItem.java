public class MenuItem {
    private String itemId, name, description;
    private double price;
    private boolean availability;

    public MenuItem(String itemId, String name, String description, double price, boolean availability) {
        this.itemId = itemId;
        this.name = name;
        this.description = description;
        this.price = price;
        this.availability = availability;
    }

    public String getItemId() { return itemId; }
    public String getName() { return name; }
    public double getPrice() { return price; }
}