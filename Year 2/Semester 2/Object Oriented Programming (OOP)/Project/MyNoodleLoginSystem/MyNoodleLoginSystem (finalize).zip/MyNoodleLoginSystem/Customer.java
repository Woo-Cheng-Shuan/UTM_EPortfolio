public class Customer extends User {
    private String username, password, phone, address, email;

    public Customer(String id, String username, String password, String name, String phone, String address, String email) {
        super(id, name);
        this.username = username;
        this.password = password;
        this.phone = phone;
        this.address = address;
        this.email = email;
    }

    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }
    public String getEmail() { return email; }
}